% Get subject info
prompt = {'Subject', 'Session', 'Block', 'Sex', 'Age', 'Deadline (0.2-5; start 0.6)', 'EEG or not'};
defAns = {'1', '1', '1', 'f', '39', '3', '0'};
box = inputdlg(prompt, 'Enter Subject Information...', 1, defAns);

if isempty(box) % Check if the user canceled input
    return; % Exit the script if input was canceled
end

p.subNum = str2double(box{1});
p.session_num = str2double(box{2});
p.runNum = str2double(box{3});
p.sex = box{4};
p.age = str2double(box{5});
p.rspdeadline = str2double(box{6});
p.EEG = str2double(box{7});

% Validate response deadline
if p.rspdeadline < 0.2 || p.rspdeadline > 5
    errordlg('Response deadline must be between 0.2 and 5 seconds.');
    return;
end

%% Serial Port connecting
if p.EEG == 1
    SerialPort = BioSemiSerialPort();
end

%%
p.s = round(sum(100*clock));
rand('state', p.s);

%%
ListenChar(2);

% build an output file name and check to make sure that it does not exist already
p.root = pwd;
if ~exist([p.root, '/data/'], 'dir')
    mkdir([p.root, '/data/']);
end

mkdir([p.root, '/data/s', num2str(p.subNum)]);
fName = [p.root, '/data/s', num2str(p.subNum), '/flanker_allages_EEG' '_sbj',  num2str(p.subNum), '_session', num2str(p.session_num),  '_block', num2str(p.runNum), '.mat'];
bName = [p.root, '/data/s', num2str(p.subNum), '/flanker_allages_EEG_code' '_sbj', num2str(p.subNum), '_session', num2str(p.session_num), '.mat'];

if exist(fName,'file')
    Screen('CloseAll');
    msgbox('File name already exists, please specify another', 'modal');
    ListenChar(0);
    return
end

abortKey = KbName('q');
%% load images
tgfolder = pwd;

FlushEvents;

% Enable UTF-8 character encoding
fontFile = 'Downloads\Niramit';
feature('DefaultCharacterSet', 'UTF8');

% Define colors and color strings
colors = [255, 0, 0; % Red
          0, 255, 0; % Green
          0, 0, 255; % Blue
          0, 0, 0]; % Black
colorStrings = {'RED', 'GREEN', 'BLUE', 'BLACK'};
colorStringsThai = {'แดง', 'เขียว', 'ฟ้า', 'ดำ'}; % Thai color strings
colorStringsMix = {colorStrings,colorStringsThai};

% Define correct responses based on key mappings
correctResponses = {'1!', '2@', '3#', '4$'}; % Key mappings for colors

% Set up screen
AssertOpenGL;
Screen('Preference', 'SkipSyncTests', 0);
screen = max(Screen('Screens'));
[win, scr_rect] = PsychImaging('OpenWindow', screen, 128, round([-1, -1, 1921, 1081]));
[winWidth, winHeight] = Screen('WindowSize', win);


% init
init1 = imread([tgfolder, '/image/TH/TF.png']);
init2 = imread([tgfolder, '/image/TH/TF (2).png']);
init3 = imread([tgfolder, '/image/TH/TF (3).png']);
init4 = imread([tgfolder, '/image/TH/TF (4).png']);
init5 = imread([tgfolder, '/image/TH/TF (5).png']);
init6 = imread([tgfolder, '/image/TH/TF (6).png']);
init7 = imread([tgfolder, '/image/TH/TF (7).png']);
init8 = imread([tgfolder, '/image/TH/TF (8).png']);
init9 = imread([tgfolder, '/image/TH/TF (9).png']);
init10 = imread([tgfolder, '/image/TH/TF (10).png']);
init11 = imread([tgfolder, '/image/TH/TF (12).png']);

init1 = Screen('MakeTexture', win, init1);
init2 = Screen('MakeTexture', win, init2);
init3 = Screen('MakeTexture', win, init3);
init4 = Screen('MakeTexture', win, init4);
init5 = Screen('MakeTexture', win, init5);
init6 = Screen('MakeTexture', win, init6);
init7 = Screen('MakeTexture', win, init7);
init8 = Screen('MakeTexture', win, init8);
init9 = Screen('MakeTexture', win, init9);
init10 = Screen('MakeTexture', win, init10);
init11 = Screen('MakeTexture', win, init11);

size(init1)


% Display the start page
Screen('DrawTexture', win, init1, [], [], []); % Display the first image
Screen('Flip', win);
KbStrokeWait;
Screen('DrawTexture', win, init2, [], [], []); % Display the second image
Screen('Flip', win);
KbStrokeWait;
Screen('DrawTexture', win, init3, [], [], []); % Display the third image
Screen('Flip', win);
KbStrokeWait;
Screen('DrawTexture', win, init4, [], [], []); % Display the second image
Screen('Flip', win);
KbStrokeWait;
Screen('DrawTexture', win, init5, [], [], []); % Display the second image
Screen('Flip', win);
KbStrokeWait;
Screen('DrawTexture', win, init6, [], [], []); % Display the second image
Screen('Flip', win);
KbStrokeWait;
Screen('DrawTexture', win, init7, [], [], []); % Display the second image
Screen('Flip', win);
KbStrokeWait;
Screen('DrawTexture', win, init8, [], [], []); % Display the second image
Screen('Flip', win);
KbStrokeWait;

trialData = {};

% Display countdown
countdownTime = 3; % Set the countdown duration in seconds
Screen('TextSize', win, 80); % Set text size for countdown
Screen('TextFont', win, 'Arial'); % Set font for countdown
for countdown = countdownTime:-1:1
    DrawFormattedText(win, sprintf('%d', countdown), 'center', 'center', [255 255 255]); % Display countdown number
    Screen('Flip', win);
    WaitSecs(1); % Wait for 1 second
end

  % Display "Go" message
  DrawFormattedText(win, 'Go', 'center', 'center', [255 255 255]);
  Screen('Flip', win);
  WaitSecs(1); % Wait for 1 second


% Run Thai language trials
trialData = runTrials(win, winWidth, winHeight, colors, colorStrings, colorStringsThai, correctResponses, p.rspdeadline, trialData, p, 'Thai');

% 30-second countdown on top of the second image
countdownDuration = 30; % Countdown duration in seconds
Screen('TextSize', win, 80); % Set text size for countdown
Screen('TextFont', win, 'Arial'); % Set font for countdown

% Define the desired vertical offset for the countdown text
  verticalOffset = 100; % Adjust this value to move the countdown lower (positive values move it down)

for countdown = countdownDuration:-1:1
    % Calculate the text position (keep horizontal center)
    textX = winWidth / 2;
    textY = winHeight / 2 + verticalOffset;
    % Draw the second image as the background
    Screen('DrawTexture', win, init9, [], [], []);
    % Draw the countdown number on top of the image
    DrawFormattedText(win, sprintf('%d', countdown), textX, textY, [255 255 255]);
    Screen('Flip', win);
    WaitSecs(1); % Wait for 1 second
end

%Show Block
Screen('DrawTexture', win, init10, [], [], []); % Display the second image
Screen('Flip', win);
KbStrokeWait;

% Display countdown
countdownTime = 3; % Set the countdown duration in seconds
Screen('TextSize', win, 80); % Set text size for countdown
Screen('TextFont', win, 'Arial'); % Set font for countdown
for countdown = countdownTime:-1:1
    DrawFormattedText(win, sprintf('%d', countdown), 'center', 'center', [255 255 255]); % Display countdown number
    Screen('Flip', win);
    WaitSecs(1); % Wait for 1 second
end

% Display "Go" message
DrawFormattedText(win, 'Go', 'center', 'center', [255 255 255]);
Screen('Flip', win);
WaitSecs(1); % Wait for 1 second

% Run Englsih language trials
trialData = runTrials(win, winWidth, winHeight, colors, colorStrings, colorStringsThai, correctResponses, p.rspdeadline, trialData, p, 'English');

% 30-second countdown on top of the second image
countdownDuration = 30; % Countdown duration in seconds
Screen('TextSize', win, 80); % Set text size for countdown
Screen('TextFont', win, 'Arial'); % Set font for countdown
verticalOffset = 100; % Adjust this value to move the countdown lower (positive values move it down)

for countdown = countdownDuration:-1:1
    % Calculate the text position (keep horizontal center)
    textX = winWidth / 2;
    textY = winHeight / 2 + verticalOffset;
    % Draw the second image as the background
    Screen('DrawTexture', win, init9, [], [], []);
    % Draw the countdown number on top of the image
    DrawFormattedText(win, sprintf('%d', countdown), textX, textY, [255 255 255]);
    Screen('Flip', win);
    WaitSecs(1); % Wait for 1 second
end

%Show Block
Screen('DrawTexture', win, init10, [], [], []); % Display the second image
Screen('Flip', win);
KbStrokeWait;
       
% Display countdown
countdownTime = 3; % Set the countdown duration in seconds
Screen('TextSize', win, 80); % Set text size for countdown    
Screen('TextFont', win, 'Arial'); % Set font for countdown
for countdown = countdownTime:-1:1
    DrawFormattedText(win, sprintf('%d', countdown), 'center', 'center', [255 255 255]); % Display countdown number
    Screen('Flip', win);
    WaitSecs(1); % Wait for 1 second
end

% Display "Go" message
DrawFormattedText(win, 'Go', 'center', 'center', [255 255 255]);
Screen('Flip', win);
WaitSecs(1); % Wait for 1 second

% Run Mixed language trials
trialData = runTrials(win, winWidth, winHeight, colors, colorStrings, colorStringsThai, correctResponses, p.rspdeadline, trialData, p, 'Mixed');

% Convert cell array to table
trialTable = cell2table(trialData(1:end, :)); % Exclude header row
% Set new headers for the table
trialTable.Properties.VariableNames = {'No.', 'Type of trial', 'Color Word', 'Ink Color','Response Color','Result Response', 'Reaction time'};
% Write trial data to CSV file
csvFileName = ['C:\Users\Toddy\Downloads\StroopTaskmunk', '/data/s', num2str(p.subNum), '/trial_dataTH.csv'];
writetable(trialTable, csvFileName);

% Clean up
ListenChar(0);
sca;

% Function to run trials for each section
function trialData = runTrials(win, winWidth, winHeight, colors, colorStrings, colorStringsThai, correctResponses, rspdeadline, trialData, p, language)
    numTrials = 60; % Total trials per section
    numCongruentTrials = 30; % Number of congruent trials per section
    numIncongruentTrials = 30; % Number of incongruent trials per section

    % Initialize arrays to track the trial types (congruent or incongruent)
    trialTypes = [ones(1, numCongruentTrials), 2 * ones(1, numIncongruentTrials)];
    trialTypes = trialTypes(randperm(numTrials)); % Randomize trial types

    if strcmpi(language, 'Mixed')
        language = repmat({'Thai', 'English'}, 1, numTrials/2); % Alternate between Thai and English languages
        % Loop through each trial
        for trial = 1:numTrials
            lang = language{trial};
            if trialTypes(trial) == 1
                trialData = runCongruentTrial(win, winWidth, winHeight, trial, numCongruentTrials, colors, colorStrings, colorStringsThai, correctResponses, rspdeadline, trialData, p, lang);
            else
                trialData = runIncongruentTrial(win, winWidth, winHeight, trial, numIncongruentTrials, colors, colorStrings, colorStringsThai, correctResponses, rspdeadline, trialData, p, lang);
            end
        end
    else
        for trial = 1:numTrials
            if trialTypes(trial) == 1
                trialData = runCongruentTrial(win, winWidth, winHeight, trial, numCongruentTrials, colors, colorStrings, colorStringsThai, correctResponses, rspdeadline, trialData, p, language);
            else
                trialData = runIncongruentTrial(win, winWidth, winHeight, trial, numIncongruentTrials, colors, colorStrings, colorStringsThai, correctResponses, rspdeadline, trialData, p, language);
            end
        end
    end
end

% Function to run congruent trials
function trialData = runCongruentTrial(win, winWidth, winHeight, trialNum, totalTrials, colors, colorStrings, colorStringsThai, correctResponses, rspdeadline, trialData, p, language)
    % Check if language is specified as Thai or English
    if strcmpi(language, 'Thai')
        % Select word and ink color from Thai options
        wordIndex = randi(length(colorStringsThai));
        wordString = colorStringsThai{wordIndex};
    elseif strcmpi(language, 'English')
        % Select word and ink color from English options
        wordIndex = randi(length(colorStrings));
        wordString = colorStrings{wordIndex};
    else
        error('Invalid language specified.');
    end

    % Set text color based on ink color (which matches the word color in congruent trials)
    inkIndex = wordIndex;
    textColor = colors(inkIndex, :);

    % Display trial number as a fraction out of totalTrials
    Screen('TextSize', win, 36);
    DrawFormattedText(win, sprintf('Trial %d / %d', trialNum, totalTrials * 2), 'center', winHeight - 50, [255 255 255]);

    % Display stimulus with text color
    Screen('TextSize', win, 256);
    Screen('TextFont', win, 'Cordia New');
    Screen('TextColor', win, textColor);
    Screen('TextStyle', win, 1);
    DispText = double(typecast(unicode2native(wordString, 'utf-16le'), 'uint16'));
    DrawFormattedText(win, DispText, 'center', 'center');
    Screen('Flip', win);

    % Record response time and accuracy
    respStart = GetSecs;
    keyPressed = false;
    reactionTime = nan; % Initialize reaction time to nan

    while GetSecs - respStart < p.rspdeadline
        [keyIsDown, ~, keyCode] = KbCheck;

        if keyIsDown
            pressedKey = KbName(keyCode);
            reactionTime = GetSecs - respStart; % Record reaction time

            if any(strcmpi(pressedKey, correctResponses))
                keyPressed = true;
                break;
            end
        end
    end

    if keyPressed
        fprintf('Answer Color: %s, Key Pressed: %s\n', colorStrings{inkIndex}, pressedKey);
    end

    % Handle response
    if keyPressed
        % Get the index of the pressed key in correctResponses
        responseIndex = find(strcmpi(pressedKey, correctResponses));

        if ~isempty(responseIndex)
            % Participant's response matches a correct response
            % Get the correct color index corresponding to the response
            correctColorIndex = responseIndex;

            % Check if displayed color matches correct response
            if correctColorIndex == inkIndex
                fprintf('Trial %d: Correct\n', trialNum);
                result = 'Correct';
                responseColor = colorStrings{correctColorIndex};
            else
                fprintf('Trial %d: Incorrect (Color mismatch)\n', trialNum);
                result = 'Incorrect';
                responseColor = colorStrings{correctColorIndex};
            end
        else
            % Participant's response does not match any correct response
            fprintf('Trial %d: Incorrect (Invalid response)\n', trialNum);
            result = 'Invalid response';
            responseColor = responseIndex;
        end
    else
        % No response detected within response deadline
        fprintf('Trial %d: No response\n', trialNum);
        result = 'No response';
        responseColor = '-';
    end

    % Create a new row for the current trial
    newTrialRow = {trialNum, 'Congruent', wordString, colorStrings{inkIndex}, responseColor, result, reactionTime};

    % Concatenate the new trial row to the existing trialData
    trialData = [trialData; newTrialRow];

    % Pause briefly before next trial
    WaitSecs(0.5);
end

% Function to run incongruent trials
function trialData = runIncongruentTrial(win, winWidth, winHeight, trialNum, totalTrials, colors, colorStrings, colorStringsThai, correctResponses, rspdeadline, trialData, p, language)
    % Check if language is specified as Thai or English
    if strcmpi(language, 'Thai')
        % Select word and ink color from Thai options
        wordIndex = randi(length(colorStringsThai));
        wordString = colorStringsThai{wordIndex};
    elseif strcmpi(language, 'English')
        % Select word and ink color from English options
        wordIndex = randi(length(colorStrings));
        wordString = colorStrings{wordIndex};
    else
        error('Invalid language specified.');
    end

    % Randomly select ink color
    inkIndex = randi(size(colors, 1));
    while inkIndex == wordIndex
        inkIndex = randi(size(colors, 1));
    end

    % Set text color based on ink color
    textColor = colors(inkIndex, :);

    % Display trial number as a fraction out of totalTrials
    Screen('TextSize', win, 36);
    DrawFormattedText(win, sprintf('Trial %d / %d', trialNum, totalTrials * 2), 'center', winHeight - 50, [255 255 255]);

    % Display stimulus with text color
    Screen('TextSize', win, 256);
    Screen('TextFont', win, 'Cordia New');
    Screen('TextColor', win, textColor);
    Screen('TextStyle', win, 1);
    DispText = double(typecast(unicode2native(wordString, 'utf-16le'), 'uint16'));
    DrawFormattedText(win, DispText, 'center', 'center');
    Screen('Flip', win);

    % Record response time and accuracy
    respStart = GetSecs;
    keyPressed = false;
    reactionTime = nan; % Initialize reaction time to nan

    while GetSecs - respStart < p.rspdeadline
        [keyIsDown, ~, keyCode] = KbCheck;

        if keyIsDown
            pressedKey = KbName(keyCode);
            reactionTime = GetSecs - respStart; % Record reaction time

            if any(strcmpi(pressedKey, correctResponses))
                keyPressed = true;
                break;
            end
        end
    end

    if keyPressed
        fprintf('Answer Color: %s, Key Pressed: %s\n', colorStrings{inkIndex}, pressedKey);
    end

    % Handle response
    if keyPressed
        % Get the index of the pressed key in correctResponses
        responseIndex = find(strcmpi(pressedKey, correctResponses));

        if ~isempty(responseIndex)
            % Participant's response matches a correct response
            % Get the correct color index corresponding to the response
            correctColorIndex = responseIndex;

            % Check if displayed color matches correct response
            if correctColorIndex == inkIndex
                fprintf('Trial %d: Correct\n', trialNum);
                result = 'Correct';
                responseColor = colorStrings{correctColorIndex};
            else
                fprintf('Trial %d: Incorrect (Color mismatch)\n', trialNum);
                result = 'Incorrect';
                responseColor = colorStrings{correctColorIndex};
            end
        else
            % Participant's response does not match any correct response
            fprintf('Trial %d: Incorrect (Invalid response)\n', trialNum);
            result = 'Invalid response';
            responseColor = responseIndex;
        end
    else
        % No response detected within response deadline
        fprintf('Trial %d: No response\n', trialNum);
        result = 'No response';
        responseColor = '-';
    end

    % Create a new row for the current trial
    newTrialRow = {trialNum, 'Incongruent', wordString, colorStrings{inkIndex}, responseColor, result, reactionTime};

    % Concatenate the new trial row to the existing trialData
    trialData = [trialData; newTrialRow];

    % Pause briefly before next trial
    WaitSecs(0.5);
end

